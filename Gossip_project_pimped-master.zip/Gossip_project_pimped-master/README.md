# The Gossip Project

Anthony KRIEF, Olivier FITOUSSI

Pour tester l'app :
* Cloner le repo
* `bundle install`
* `rails db:migrate`
* `rails db:seed`
* `rails server`
* Se rendre sur localhost:3000/ dans le navigateur
